package com.br.projetomobile1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase banco;

    public ClienteDAO(Context context){
        databaseHelper = new DatabaseHelper(context);
        banco = databaseHelper.getWritableDatabase();

    } // inserir dos Clientes
    public long inserir(Clientes clientes){
        ContentValues values =  new ContentValues();
        values.put("nome", clientes.getNome());
        values.put("rg", clientes.getRg());
        values.put("email", clientes.getEmail());
        values.put("telefone", clientes.getTelefone());
        return banco.insert("clientes", null, values);


    }
     public List<Clientes> obterTODOS(){
        List<Clientes> clientes = new ArrayList<>();
         Cursor cursor = banco.query("clientes", new String[]{"id", "nome", "rg", "email", "telefone"},
                 null, null, null, null,null);



         while (cursor.moveToNext()) {
             Clientes p = new Clientes();
             p.setId(cursor.getInt(0));
             p.setNome(cursor.getString(1));
             p.setRg(cursor.getString(2));
             p.setEmail(cursor.getString(3));
             p.setTelefone(cursor.getString(4));
             clientes.add(p);
         }
         return  clientes;

     }
     public void excluir (Clientes p){
        banco.delete("clientes", "id = ?", new String[]{p.getId().toString()});


     }
     public void atualizar(Clientes clientes){
         ContentValues values = new ContentValues();
         values.put("nome", clientes.getNome());
         values.put("rg", clientes.getRg());
         values.put("email", clientes.getEmail());
         values.put("telefone", clientes.getTelefone());
         banco.update("clientes", values, "id = ?", new String[]{clientes.getId().toString()});

         }
    public ArrayList<String> getClientes() {
        ArrayList<String> clientes = new ArrayList<String>( );
        Cursor cursor = banco.rawQuery("SELECT * FROM Clientes", null);
        if (cursor != null && cursor.moveToFirst( )) {
            do {
                clientes.add(cursor.getString(cursor.getColumnIndex("nome")));
            } while (cursor.moveToNext( ));
        }
        return clientes;


    }


}

