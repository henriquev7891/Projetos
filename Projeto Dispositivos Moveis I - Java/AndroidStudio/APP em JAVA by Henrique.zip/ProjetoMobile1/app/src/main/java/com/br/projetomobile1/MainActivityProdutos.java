package com.br.projetomobile1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivityProdutos extends AppCompatActivity implements View.OnClickListener {

    Button btnClick;

    private EditText nome;
    private EditText descricao;
    private ProdutoDAO dao;
    private Produtos produtos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_produtos);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("Cadastro de Produtos");
         btnClick = (Button) findViewById(R.id.btnSalvar_Produtos);
         btnClick.setOnClickListener(this);

         nome = findViewById(R.id.editNome);
         descricao = findViewById(R.id.editDescricao);
         dao = new ProdutoDAO(this);

        Intent it = getIntent( );
        if (it.hasExtra("produto")) {
            produtos = (Produtos)

            it.getSerializableExtra("produto");
            nome.setText(produtos.getNome( ));
            descricao.setText(produtos.getDescricao( ));

        }
        Button btnListar_produtos = findViewById(R.id.btnListar_Produtos);

        btnListar_produtos.setOnClickListener(new View.OnClickListener( ) {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext( ), MainActivityListar_Produtos.class);
                startActivity(intent);
            }

        });

    }


    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnSalvar_Produtos) {
            //Inseri os Dados no banco
            if (produtos == null) {
                produtos = new Produtos( );

                produtos.setNome(nome.getText( ).toString( ));
                produtos.setDescricao(descricao.getText( ).toString( ));
                long id = dao.inserir(produtos);
                Toast.makeText(this, "Produto inserido com id: " + id, Toast.LENGTH_SHORT).show( );
            } else {
                produtos.setNome(nome.getText( ).toString( ));
                produtos.setDescricao(descricao.getText( ).toString( ));
                dao.atualizar(produtos);
                Toast.makeText(this, "Produto foi atualizado", Toast.LENGTH_SHORT).show( );


            }
            limparCampos( );
            }
        }
        //metodo para limpar os campos
        public void limparCampos ()

        {
            nome.getText().clear();
            descricao.getText() .clear();



            Toast.makeText(getApplicationContext(), "O Formulario de Produto foi limpo",Toast.LENGTH_SHORT).show();
        }
        @Override
        public boolean onOptionsItemSelected(MenuItem item)
        {
            int id = item.getItemId();

            if (id == android.R.id.home)
            {
                finish();
                return true;
            }
            return super.onOptionsItemSelected(item);

        }

    }
