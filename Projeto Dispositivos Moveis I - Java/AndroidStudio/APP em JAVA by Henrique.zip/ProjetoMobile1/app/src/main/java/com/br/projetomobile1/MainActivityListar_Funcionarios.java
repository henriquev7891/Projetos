package com.br.projetomobile1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

public class MainActivityListar_Funcionarios extends AppCompatActivity {



    private ListView listView;
    private FuncionarioDAO dao;
    private List<Funcionarios> funcionarios;
    private List<Funcionarios> funcionariosfiltrados = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_listar__funcionarios);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("ListarFuncionarios");

        listView = findViewById(R.id.ListView_Lista_Funcinarios);

        dao = new FuncionarioDAO(this);
        funcionarios = dao.obterTODOS( );
        funcionariosfiltrados.addAll(funcionarios);
        ArrayAdapter<Funcionarios> adaptador = new ArrayAdapter<Funcionarios>(this, android.R.layout.simple_list_item_1, funcionariosfiltrados);

        listView.setAdapter(adaptador);

        registerForContextMenu(listView);

    }
    public boolean onCreateOptionsMenu (Menu menu) {

        MenuInflater i = getMenuInflater( );
        i.inflate(R.menu.menu_cadastro, menu);

        SearchView sv = (SearchView) menu.findItem(R.id.app_bar_search).getActionView( );
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener( ) {
            @Override
            public boolean onQueryTextSubmit(String query) {return false;}

            @Override
            public boolean onQueryTextChange(String newText) {
                 procuraFuncionario(newText);

                return false;
            }


        });
        return true;
    }
    public void procuraFuncionario (String nome){
        funcionariosfiltrados.clear();
        for(Funcionarios f : funcionarios){
            if(f.getNome() .toLowerCase().contains(nome.toLowerCase())){
                funcionariosfiltrados.add(f);
            }
        }
        listView.invalidateViews();
    }

    public void cadastrar (MenuItem item){
        Intent it = new Intent(this, MainActivityFuncionarios.class);
                startActivity(it);

    }
    public void excluir(MenuItem item){
        AdapterView.AdapterContextMenuInfo menuInfo =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
       final Funcionarios funcionarioExcluir = funcionariosfiltrados.get(menuInfo.position);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Atenção")
                .setMessage("Realmente deseja exluir o funcionario?")
                .setNegativeButton("NÂO", null)
                .setPositiveButton("SIM", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i){
                        funcionariosfiltrados.remove(funcionarioExcluir);
                        funcionarios.remove(funcionarioExcluir);
                        dao.excluir(funcionarioExcluir);
                        listView.invalidateViews();

                    }
                }).create();
        dialog.show();

    }
    public void atualizar(MenuItem item){
        AdapterView.AdapterContextMenuInfo menuInfo =
                (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        final Funcionarios funcionarioAtualizar = funcionariosfiltrados.get(menuInfo.position);
        Intent it = new Intent(this, MainActivityFuncionarios.class);
        it.putExtra("funcionario", funcionarioAtualizar);
        startActivity(it);

    }
    @Override
    public void onResume(){
        super.onResume();
        funcionarios = dao.obterTODOS();
        funcionariosfiltrados.clear();
        funcionariosfiltrados.addAll(funcionarios);
        listView.invalidateViews();

    }
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.menu_contexto, menu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if (id == android.R.id.home)
        {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}


