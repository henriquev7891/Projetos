package com.br.projetomobile1;          //Bean Clientes

import java.io.Serializable;
import java.util.List;

public class Clientes  implements Serializable {

    private Integer id_cliente;
    private String nome;
    private String rg;
    private String email;
    private String telefone;



    public Integer getId () {
            return id_cliente;
        }

        public void setId (Integer id){
            this.id_cliente = id;
        }

        public String getNome () {
            return nome;
        }

        public void setNome (String nome){
            this.nome = nome;
        }

        public String getRg () {
            return rg;
        }

        public void setRg (String rg){
            this.rg = rg;
        }

        public String getEmail () {
            return email;
        }

        public void setEmail (String email){
            this.email = email;
        }

        public String getTelefone () {
            return telefone;
        }

        public void setTelefone (String telefone){
            this.telefone = telefone;
        }


        @Override
        public String toString () {

            return id_cliente + "-" + nome + "-" + rg + "-" + email + "-" + telefone;
        }
    }


