package com.br.projetomobile1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

class DatabaseHelper  extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "banco_database";
    private static final String Funcionarios = "funcionarios";
    private static final String Clientes = "clientes";
    private static final String Produtos = "produtos";
    private static final String CliProd = "cliprod";


    DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 5);

    }


    //Inicializacao da Variavel
    @Override
    public void onCreate(SQLiteDatabase db) {
        //Criar as Tabelas
        String funcionarios = "CREATE TABLE " + Funcionarios + " (id integer primary key autoincrement, " +
                "nome varchar(50), rg varchar(50), email varchar(50), telefone varchar(50), senha varchar(50) )";
        String clientes = "CREATE TABLE " + Clientes + " (id integer primary key autoincrement, " +
                "nome varchar(50), rg varchar(50), email varchar(50), telefone varchar(50))";
        String produtos = "CREATE TABLE " + Produtos + " (id integer primary key autoincrement, " +
                "nome varchar(50), descricao varchar(100))";
        String cliprod = "CREATE TABLE " + CliProd + " (id integer primary key autoincrement, " +
                "cliente varchar(50), produto varchar(50))";


        db.execSQL(funcionarios);
        db.execSQL(clientes);
        db.execSQL(produtos);
        db.execSQL(cliprod);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop Existing Table
        db.execSQL("DROP TABLE IF EXISTS " + Funcionarios);
        db.execSQL("DROP TABLE IF EXISTS " + Clientes);
        db.execSQL("DROP TABLE IF EXISTS " + Produtos);
        db.execSQL("DROP TABLE IF EXISTS " + CliProd);


        onCreate(db);


    }
    // Lista Clientes
    public ArrayList<String> clientes() {
        ArrayList<String> list = new ArrayList<String>( );
        SQLiteDatabase db = this.getReadableDatabase( );
        db.beginTransaction( );
        try {
            String selectQuery = "SELECT * FROM " + Clientes;
            Cursor cursor = db.rawQuery(selectQuery, null);
            if (cursor.getCount( ) > 0) {
                while (cursor.moveToNext( )) {
                    String nome = cursor.getString(cursor.getColumnIndex("nome"));
                    list.add(nome);
                }
            }
            db.setTransactionSuccessful( );


        } catch (Exception e) {
            e.printStackTrace( );
        } finally {
            db.endTransaction( );
            db.close( );

        }
        return list;
    }
        // Busca Clientes
    public ArrayList<String> buscaDadosSpinnerclientes() {
        SQLiteDatabase db = getReadableDatabase( );
        String sql_busca_dados_spinnerclientes = "SELECT * FROM " + Clientes;

        ArrayList<String> clientes = new ArrayList<>( );

        Cursor cursor = db.rawQuery(sql_busca_dados_spinnerclientes, null);
        while (cursor.moveToNext( )) {
            clientes.add(cursor.getString(cursor.getColumnIndex("nome")));
        }
        db.close();
        return clientes;


    }
    // Busca Produtos
    public ArrayList<String> buscaDadosSpinnerprodutos() {
        SQLiteDatabase db = getReadableDatabase( );
        String sql_busca_dados_spinnerprodutos = "SELECT * FROM " + Produtos;

        ArrayList<String> produtos = new ArrayList<>( );

        Cursor cursor = db.rawQuery(sql_busca_dados_spinnerprodutos, null);
        while (cursor.moveToNext( )) {
            produtos.add(cursor.getString(cursor.getColumnIndex("nome")));
        }
        return produtos;

    }   // Inseri clientes / relacao
    public void inseriDadosSpinner(String clientes){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cliente = new ContentValues();
        cliente.put("dados", clientes);
        db.insert("CliProd",null,cliente);
        db.close();

    }
}








