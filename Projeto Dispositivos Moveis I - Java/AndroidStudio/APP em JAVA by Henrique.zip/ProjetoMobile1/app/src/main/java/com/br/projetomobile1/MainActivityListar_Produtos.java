package com.br.projetomobile1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.List;

public class MainActivityListar_Produtos extends AppCompatActivity {

    private ListView listView;
    private ProdutoDAO dao;
    private List<Produtos> produtos;
    private List<Produtos> produtosfiltrados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_listar__produtos);

        getSupportActionBar( ).setDisplayHomeAsUpEnabled(true);

        getSupportActionBar( ).setTitle("Listar Produtos");

        listView = findViewById(R.id.ListView_Lista_Produtos);

        dao = new ProdutoDAO(this);
        produtos = dao.obterTODOS( );
        produtosfiltrados.addAll(produtos);
        ArrayAdapter<Produtos> adaptador = new ArrayAdapter<Produtos>(this, android.R.layout.simple_list_item_1, produtosfiltrados);

        listView.setAdapter(adaptador);

        registerForContextMenu(listView);

    }
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.menu_cadastro, menu);

        SearchView sv = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener( ) {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                procuraProduto(s);
                return false;
            }
        });
        return true;
    }
    public void procuraProduto(String nome){
        produtosfiltrados.clear();
        for (Produtos m : produtos){
            if (m.getNome().toLowerCase().contains(nome.toLowerCase())){
                produtosfiltrados.add(m);
            }
        }
        listView.invalidateViews();
    }
    public void cadastrar(MenuItem item){
        Intent it = new Intent(this, MainActivityProdutos.class);
        startActivity(it);

    }
    public void excluir(MenuItem item){
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        final Produtos produtosExcluir = produtosfiltrados.get(menuInfo.position);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Atenção")
                .setMessage("Realmente deseja excluir o Produto?")
                .setNegativeButton("NÂO", null)
                .setPositiveButton("SIM", new DialogInterface.OnClickListener( ) {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        produtosfiltrados.remove(produtosExcluir);
                        produtos.remove(produtosExcluir);
                        dao.excluir(produtosExcluir);
                        listView.invalidateViews();
                    }
                }).create();
        dialog.show();
    }
    public void atualizar(MenuItem item){
        AdapterView.AdapterContextMenuInfo menuInfo = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        final Produtos produtoAtualizar = produtosfiltrados.get(menuInfo.position);
        Intent it = new Intent(this, MainActivityProdutos.class);
        it.putExtra("produto", produtoAtualizar);
        startActivity(it);


    }
    @Override
    public void onResume(){
        super.onResume();
        produtos = dao.obterTODOS();
        produtosfiltrados.clear();
        produtosfiltrados.addAll(produtos);
        listView.invalidateViews();

    }
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater i = getMenuInflater();
        i.inflate(R.menu.menu_contexto, menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if(id == android.R.id.home)
        {
            finish();
            return true;

        }
        return super.onOptionsItemSelected(item);

    }

}



