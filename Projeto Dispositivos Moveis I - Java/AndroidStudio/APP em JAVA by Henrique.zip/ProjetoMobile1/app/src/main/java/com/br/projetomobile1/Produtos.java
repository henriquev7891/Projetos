package com.br.projetomobile1;          //Bean Produtos

import java.io.Serializable;

public class Produtos  implements Serializable {

    private Integer id_produto;
    private String nome;
    private String descricao;


    //getters e Setters


    public Integer getId() {
        return id_produto;
    }

    public void setId(Integer id) {
        this.id_produto = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    @Override
    public String toString (){
        return id_produto + "-" + nome+ "-" + descricao ;
    }

}
