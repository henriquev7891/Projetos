package com.br.projetomobile1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

    public class CliProdDAO {

        private DatabaseHelper databaseHelper;
        private SQLiteDatabase banco;


        public CliProdDAO(Context context) {
            databaseHelper = new DatabaseHelper(context);
            banco = databaseHelper.getWritableDatabase( );

        }

        public long inserir(CliProd cliProd) {
            ContentValues values = new ContentValues( );
            values.put("cliente", cliProd.getCliente( ));
            values.put("produto", cliProd.getProduto( ));
            return banco.insert("cliProd", null, values);
        }

        public List<CliProd> obterTODOS() {
            List<CliProd> cliProd = new ArrayList<>( );
            Cursor cursor = banco.query("cliProd", new String[]{"id", "cliente", "produto"},
                    null, null, null, null, null);
            while (cursor.moveToNext( )) {
                CliProd m = new CliProd( );
                m.setId(cursor.getInt(0));
                m.setCliente(cursor.getString(1));
                m.setProduto(cursor.getString(2));
                cliProd.add(m);
            }
            return cliProd;

        }


        //metodo para DeletarCliProd
        public void excluir(CliProd pm) {

        }




            public ArrayList<String> getCliProd () {
                ArrayList<String> cliProd = new ArrayList<String>( );
                Cursor cursor = banco.rawQuery("SELECT * FROM CliProd", null);
                if (cursor != null && cursor.moveToFirst( )) {
                    do {
                        cliProd.add(cursor.getString(cursor.getColumnIndex("nome")));
                    } while (cursor.moveToNext( ));
                }
                return cliProd;


            }


        }

