package com.br.projetomobile1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivityFuncionarios extends AppCompatActivity implements View.OnClickListener{
    Button btnClick;

    DatabaseHelper databaseHelper;

    private EditText nome;
    private EditText rg;
    private EditText email;
    private EditText telefone;
    private EditText senha;
    private FuncionarioDAO dao;
    private Funcionarios funcionarios = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_funcionarios);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("Cadastro de Funcionarios");

        btnClick  = (Button) findViewById(R.id.btnSalvar_Funcionarios);
        btnClick.setOnClickListener(this);

        nome = findViewById(R.id.editNome);
        rg = findViewById(R.id.editRG);
        email = findViewById(R.id.editEmail);
        telefone = findViewById(R.id.editTelefone);
        senha = findViewById(R.id.editSenha);
        dao = new FuncionarioDAO(this);

        Intent it = getIntent();
        if (it.hasExtra("funcionario")) {
            funcionarios = (Funcionarios) it.getSerializableExtra("funcionario");
            nome.setText(funcionarios.getNome());
            rg.setText(funcionarios.getRg());
            email.setText(funcionarios.getEmail());
            telefone.setText(funcionarios.getTelefone());
            senha.setText(funcionarios.getSenha());
        }

        Button btnListar_Funcionarios = findViewById(R.id.btnListar_Funcionarios);

        btnListar_Funcionarios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivityListar_Funcionarios.class);
                startActivity(intent);
            }

        });

    }





    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnSalvar_Funcionarios){
            //Todo Codigo
                    if (funcionarios == null) {
                    funcionarios = new Funcionarios();

                    funcionarios.setNome(nome.getText().toString());
                    funcionarios.setRg(rg.getText().toString());
                    funcionarios.setEmail(email.getText().toString());
                    funcionarios.setTelefone(telefone.getText().toString());
                    funcionarios.setSenha(senha.getText().toString());
                    long id = dao.inserir(funcionarios);
                    Toast.makeText(this, "Funcionario inserido com id: " + id, Toast.LENGTH_SHORT).show();
                }else{
                    funcionarios.setNome(nome.getText().toString());
                    funcionarios.setRg(rg.getText().toString());
                    funcionarios.setEmail(email.getText().toString());
                    funcionarios.setTelefone(telefone.getText().toString());
                    funcionarios.setSenha(senha.getText().toString());
                    dao.atualizar(funcionarios);
                    Toast.makeText(this, "Funcionario foi atualizado", Toast.LENGTH_SHORT).show();

                }
                limparCampos();

            Intent intent = new Intent(getApplicationContext(), MainActivityListar_Funcionarios.class);
            startActivity(intent);


            }


    }
    //metodo para limpar os campos
    public void limparCampos ()
    {
        //LImpando


        nome.getText().clear();
        rg.getText().clear();
        email.getText().clear();
        telefone.getText().clear();
        senha.getText().clear();


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id = item.getItemId();

        if (id == android.R.id.home)
        {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}



