package com.br.projetomobile1;  //Bean Funcionarios

import android.widget.ListView;

import java.io.Serializable;

public class Funcionarios implements Serializable {

    private Integer id_funcionario;
    private String nome;
    private String rg;
    private String email;
    private String telefone;
    private String senha;

    public Integer getId() {
        return id_funcionario;
    }

    public void setId(Integer id) {
        this.id_funcionario = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    @Override
    public String toString (){

        return id_funcionario + "-" + nome+ "-" + rg + "-" + email+ "-" + telefone + "-" + senha ;
    }
}
