package com.br.projetomobile1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivityClientes extends AppCompatActivity implements View.OnClickListener {

    Button btnClick;

    private EditText nome;
    private EditText rg;
    private EditText email;
    private EditText telefone;
    private ClienteDAO dao;
    private Clientes clientes = null;

    DatabaseHelper databaseHelper;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_clientes);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getSupportActionBar().setTitle("Cadastro de Clientes");

        btnClick = (Button) findViewById(R.id.btnSalvar_Clientes);
        btnClick.setOnClickListener(this);

        nome = findViewById(R.id.editNome);
        rg = findViewById(R.id.editRG);
        email = findViewById(R.id.editEmail);
        telefone = findViewById(R.id.editTelefone);
        dao = new ClienteDAO(this);

       Intent it = getIntent();
       if (it.hasExtra("cliente")){
           clientes = (Clientes)
                   it.getSerializableExtra("cliente");
           nome.setText(clientes.getNome());
           rg.setText(clientes.getRg());
           email.setText(clientes.getEmail());
           telefone.setText(clientes.getTelefone());
       }

        Button btnListar_Clientes = findViewById(R.id.btnListar_Clientes);

        btnListar_Clientes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivityListar_Clientes.class);
                startActivity(intent);
            }

        });

    }

    @Override
    public void onClick(View v) {
       if (v.getId() == R.id.btnSalvar_Clientes){
           //todo Codigo
           if (clientes == null){
               clientes = new Clientes();

               clientes.setNome(nome.getText().toString());
               clientes.setRg(rg.getText().toString());
               clientes.setEmail(email.getText().toString());
               clientes.setTelefone(telefone.getText().toString());
               long id = dao.inserir(clientes);
               Toast.makeText(this, "Cliente inserido com id:" + id, Toast.LENGTH_SHORT).show();
           }else{
               clientes.setNome(nome.getText().toString());
               clientes.setRg(rg.getText().toString());
               clientes.setEmail(email.getText().toString());
               clientes.setTelefone(telefone.getText().toString());
               dao.atualizar(clientes);
               Toast.makeText(this, "Cliente foi atualizado com sucesso!", Toast.LENGTH_SHORT).show();
           }
               limparCampos();
           Intent intent = new Intent(getApplicationContext(), MainActivityListar_Clientes.class);
           startActivity(intent);

           }


    }
    //metodo para limpar os campos
    public void limparCampos ()
    {
        //limpando

        nome.getText().clear();
        rg.getText().clear();
        email.getText().clear();
        telefone.getText().clear();


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
       int id = item.getItemId();

       if(id ==  android.R.id.home)
       {
           finish();
           return true;
       }
       return super.onOptionsItemSelected(item);
    }

}
