package com.br.projetomobile1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class FuncionarioDAO {

    private DatabaseHelper databaseHelper;
    private SQLiteDatabase banco;

    public FuncionarioDAO(Context context) {
        databaseHelper = new DatabaseHelper(context);
        banco = databaseHelper.getWritableDatabase();
    }

    public long inserir(Funcionarios funcionarios) {
        ContentValues values = new ContentValues();
        values.put("nome", funcionarios.getNome());
        values.put("rg", funcionarios.getRg());
        values.put("email", funcionarios.getEmail());
        values.put("telefone", funcionarios.getTelefone());
        values.put("senha", funcionarios.getSenha());
        return banco.insert("funcionarios", null, values);

    }

    public List<Funcionarios> obterTODOS() {
        List<Funcionarios> funcionarios = new ArrayList<>();
        Cursor cursor = banco.query("funcionarios", new String[]{"id", "nome", "rg", "email", "telefone", "senha"},
                null, null, null, null, null);
        while (cursor.moveToNext()) {
            Funcionarios f = new Funcionarios();
            f.setId(cursor.getInt(0));
            f.setNome(cursor.getString(1));
            f.setRg(cursor.getString(2));
            f.setEmail(cursor.getString(3));
            f.setTelefone(cursor.getString(4));
            f.setSenha(cursor.getString(5));
            funcionarios.add(f);
        }
        return funcionarios;


    }
    public void excluir (Funcionarios f){
        banco.delete("funcionarios", "id = ?", new String[]{f.getId().toString()});
    }
    public void atualizar(Funcionarios funcionarios){
        ContentValues values = new ContentValues();
        values.put("nome", funcionarios.getNome());
        values.put("rg", funcionarios.getRg());
        values.put("email", funcionarios.getEmail());
        values.put("telefone", funcionarios.getTelefone());
        values.put("senha", funcionarios.getSenha());
        banco.update("funcionarios", values,
                "id = ?", new String[]{funcionarios.getId().toString()});

    }
}