package com.br.projetomobile1;      //Bean Relacao

import java.io.Serializable;
import java.util.List;

public class CliProd implements Serializable {


    public static List<CliProd> listAll;
    private Integer id_cliprod;
    private String cliente;
    private String produto;


    public Integer getId () { return id_cliprod;  }

    public void setId (Integer id) { this.id_cliprod = id;    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    @Override
    public String toString (){

    return id_cliprod + "-" +cliente+ "-" + produto;
    }


}

