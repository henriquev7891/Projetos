package com.br.projetomobile1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ComponentActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static com.br.projetomobile1.R.id.editCliente;


public class MainActivityCliProd extends AppCompatActivity implements View.OnClickListener {

    Button btnClick;

    private DatabaseHelper databaseHelper;

    private EditText produto;
    private EditText cliente;
    private CliProdDAO dao;
    private CliProd cliProd = null;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_cli_prod);

        getSupportActionBar( ).setDisplayHomeAsUpEnabled(true);

        getSupportActionBar( ).setTitle("Cadastro Clientes_Produtos");

        btnClick = (Button) findViewById(R.id.btnSalvar_CliProd);
        btnClick.setOnClickListener(this);

        cliente = findViewById(R.id.editCliente);
        produto = findViewById(R.id.editProduto);

        dao = new CliProdDAO(this);

        Intent it = getIntent( );
        if (it.hasExtra("cliente")) {
            cliProd = (CliProd)
                    it.getSerializableExtra("cliente");
            cliente.setText(cliProd.getCliente( ));
            produto.setText(cliProd.getProduto( ));

        }


        final TextView textViewCliente = findViewById(R.id.editCliente);
        final Spinner spinnerclientes = findViewById(R.id.spinnerClientes);

        final TextView textViewProduto = findViewById(R.id.editProduto);
        final Spinner spinnerprodutos = findViewById(R.id.spinnerProdutos);


        spinnerclientes.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener( ) {


            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                textViewCliente.setText(spinnerclientes.getSelectedItem( ).toString( ));

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spinnerprodutos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener( ) {


            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                textViewProduto.setText(spinnerprodutos.getSelectedItem( ).toString( ));

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        DatabaseHelper databaseHelper = new DatabaseHelper(this);

        ArrayAdapter<String> adapter_spinnerclientes = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, databaseHelper.buscaDadosSpinnerclientes( ));

        spinnerclientes.setAdapter(adapter_spinnerclientes);


        ArrayAdapter<String> adapter_spinnerprodutos = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, databaseHelper.buscaDadosSpinnerprodutos( ));

        spinnerprodutos.setAdapter(adapter_spinnerprodutos);
    }


    @Override
    public void onClick(View v) {
        if (v.getId( ) == R.id.btnSalvar_CliProd) {
            //todo Codigo
            if (cliProd == null) {
                cliProd = new CliProd( );

                cliProd.setCliente(cliente.getText( ).toString( ));
                cliProd.setProduto(produto.getText( ).toString( ));
                long id = dao.inserir(cliProd);
                Toast.makeText(this, "Cliente inserido com id:" + id, Toast.LENGTH_SHORT).show( );
            }

            Button btnListar_CliProd = findViewById(R.id.btnListar_CliProd);

            btnListar_CliProd.setOnClickListener(new View.OnClickListener( ) {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext( ), MainActivityListar_CliProd.class);
                    startActivity(intent);
                }

            });

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId( );

        if (id == android.R.id.home) {
            finish( );
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}















