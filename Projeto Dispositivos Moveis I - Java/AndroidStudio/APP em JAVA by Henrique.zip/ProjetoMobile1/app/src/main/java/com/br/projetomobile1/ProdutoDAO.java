package com.br.projetomobile1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {

    private DatabaseHelper  databaseHelper;

    private SQLiteDatabase banco;


    public ProdutoDAO(Context context){
        databaseHelper = new DatabaseHelper(context);
        banco = databaseHelper.getWritableDatabase();

    }
    //medoto inserir
    public long inserir(Produtos produtos){
        ContentValues values = new ContentValues();
        values.put("nome", produtos.getNome());
        values.put("descricao", produtos.getDescricao());
        return banco.insert("produtos", null, values);

    }
    public List<Produtos> obterTODOS(){
        List<Produtos> produtos = new ArrayList<>();
        Cursor cursor = banco.query("produtos", new String[]{"id", "nome", "descricao"},
                null,null,null, null,null);
        while (cursor.moveToNext())
        {
            Produtos m = new Produtos();
            m.setId(cursor.getInt(0));
            m.setNome(cursor.getString(1));
            m.setDescricao(cursor.getString(2));
            produtos.add(m);
        }
        return produtos;


    }
    //metodo para Deletar Produto
    public void excluir (Produtos m){
        banco.delete("produtos", "id = ?", new String[]{m.getId().toString()});
    }
    //metodo para Atualizar Produto
    public int atualizar(Produtos produtos){
        ContentValues values = new ContentValues();
        values.put("nome", produtos.getNome());
        values.put("descricao", produtos.getDescricao());
        return banco.update("produtos", values, "id = ?", new String[]{produtos.getId().toString()});
    }
}


