/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.beans;

/**
 *
 * @author User
 */
public class Produto {
    
    int id;
    String nome;
    String fornecedor;
    String valor;
    String validade;

    public Produto(int id) {
        this.id = id;
    }

    public Produto(String nome) {
        this.nome = nome;
    }

    public Produto(String nome, String fornecedor, String valor, String validade) {
        this.nome = nome;
        this.fornecedor = fornecedor;
        this.valor = valor;
        this.validade = validade;
    }

    public Produto(int id, String nome, String fornecedor, String valor, String validade) {
        this.id = id;
        this.nome = nome;
        this.fornecedor = fornecedor;
        this.valor = valor;
        this.validade = validade;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(String fornecedor) {
        this.fornecedor = fornecedor;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getValidade() {
        return validade;
    }

    public void setValidade(String validade) {
        this.validade = validade;
    }

    @Override
    public String toString() {
        return "Produto{" + "id=" + id + ", nome=" + nome + ", fornecedor=" + fornecedor + ", valor=" + valor + ", validade=" + validade + '}';
    }


}
