/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.beans;

/**
 *
 * @author User
 */
public class Departamento {
    
    int id;
    String nome;
    String desc;
    String centrocusto;

    public Departamento(int id) {
        this.id = id;
    }

    public Departamento(String nome) {
        this.nome = nome;
    }

    public Departamento(String nome, String desc, String centrocusto) {
        this.nome = nome;
        this.desc = desc;
        this.centrocusto = centrocusto;
    }

    public Departamento(int id, String nome, String desc, String centrocusto) {
        this.id = id;
        this.nome = nome;
        this.desc = desc;
        this.centrocusto = centrocusto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getCentrocusto() {
        return centrocusto;
    }

    public void setCentrocusto(String centrocusto) {
        this.centrocusto = centrocusto;
    }

    @Override
    public String toString() {
        return "Departamento{" + "id=" + id + ", nome=" + nome + ", desc=" + desc + ", centrocusto=" + centrocusto + '}';
    }
    
    
   
    
}
