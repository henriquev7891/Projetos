/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.telas;

import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import revisaodmd2021m.beans.Departamento;
import revisaodmd2021m.controles.ControleDepartamento;

/**
 *
 * @author User
 */
public class ManterDepartamento {
    
    static int id;
    static String nome;
    static String desc;
    static String centrocusto;
    static ControleDepartamento contD;
    
    public static void buscar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE BUSCAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Departamento dEntrada = new Departamento(id);
        contD = new ControleDepartamento();
        Departamento dSaida = contD.buscar(dEntrada);
        System.out.println(dSaida.toString());
        JOptionPane.showMessageDialog(null,dSaida.toString());
    }

    public static void listar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE LISTAR");
        nome = JOptionPane.showInputDialog("NOME");
        Departamento dEntrada = new Departamento(nome);
        contD = new ControleDepartamento();
        List<Departamento> dsSaida = contD.listar(dEntrada);
        dsSaida.forEach((depL) -> {
            JOptionPane.showMessageDialog(null,depL.toString());
        });
    }

    public static void inserir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE INSERIR");
        nome = JOptionPane.showInputDialog("NOME");
        desc = JOptionPane.showInputDialog("DESC");
        centrocusto = JOptionPane.showInputDialog("C_CUSTO");
        Departamento dEntrada = new Departamento(nome,desc,centrocusto);
        contD = new ControleDepartamento();
        Departamento dSaida = contD.inserir(dEntrada);
        JOptionPane.showMessageDialog(null,dSaida.toString());
    }
    
    public static void alterar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE ALTERAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        nome = JOptionPane.showInputDialog("NOME");
        desc = JOptionPane.showInputDialog("DESC");
        centrocusto = JOptionPane.showInputDialog("C_CUSTO");
        Departamento dEntrada = new Departamento(id,nome,desc,centrocusto);
        contD = new ControleDepartamento();
        Departamento dSaida = contD.alterar(dEntrada);
        JOptionPane.showMessageDialog(null,dSaida.toString());
    }

    public static void excluir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE EXCLUIR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Departamento dEntrada = new Departamento(id);
        contD = new ControleDepartamento();
        Departamento dSaida = contD.excluir(dEntrada);
        System.out.println(dSaida.toString());
        JOptionPane.showMessageDialog(null,dSaida.toString());
    }

}
