/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.telas;

import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import revisaodmd2021m.beans.Pessoa;
import revisaodmd2021m.controles.ControlePessoa;

/**
 *
 * @author User
 */
public class ManterPessoa {
    
    static int id;
    static String nome;
    static String idade;
    static String altura;
    static String peso;
    static String genero;

    static ControlePessoa contP;
    
    public static void listar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE LISTAR");
        nome = JOptionPane.showInputDialog("NOME");
        Pessoa pEntrada = new Pessoa(nome);
        contP = new ControlePessoa();
        List<Pessoa> psSaida = contP.listar(pEntrada);
        psSaida.forEach((pesL) -> {
            JOptionPane.showMessageDialog(null,pesL.toString());
        });
    }

    public static void inserir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE INSERIR");
        nome = JOptionPane.showInputDialog("NOME");
        idade = JOptionPane.showInputDialog("IDADE");
        altura = JOptionPane.showInputDialog("ALTURA");
        peso = JOptionPane.showInputDialog("PESO");
        genero = JOptionPane.showInputDialog("GENERO");
        Pessoa pEntrada = new Pessoa(nome,peso,idade,altura,genero);
        contP = new ControlePessoa();
        Pessoa pSaida = contP.inserir(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }
    
    public static void alterar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE ALTERAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        nome = JOptionPane.showInputDialog("NOME");
        idade = JOptionPane.showInputDialog("IDADE");
        altura = JOptionPane.showInputDialog("ALTURA");
        peso = JOptionPane.showInputDialog("PESO");
        genero = JOptionPane.showInputDialog("GENERO");
        Pessoa pEntrada = new Pessoa(id,nome,peso,idade,altura,genero);
        contP = new ControlePessoa();
        Pessoa pSaida = contP.alterar(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }
    
    public static void buscar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE BUSCAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Pessoa pEntrada = new Pessoa(id);
        contP = new ControlePessoa();
        Pessoa pSaida = contP.buscar(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }

    public static void excluir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE EXCLUIR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Pessoa pEntrada = new Pessoa(id);
        contP = new ControlePessoa();
        Pessoa pSaida = contP.excluir(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }

}
