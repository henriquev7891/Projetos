package revisaodmd2021m.telas;

import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import revisaodmd2021m.beans.Produto;
import revisaodmd2021m.controles.ControleProduto;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author User
 */
public class ManterProduto {
    
    
    static int id;
    static String nome;
    static String fornecedor;
    static String valor;
    static String validade;
    
    static ControleProduto contP;
    
    public static void listar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE LISTAR");
        nome = JOptionPane.showInputDialog("NOME");
        Produto pEntrada = new Produto(nome);
        contP = new ControleProduto();
        List<Produto> prSaida = contP.listar(pEntrada);
        prSaida.forEach((produL) -> {
            JOptionPane.showMessageDialog(null,produL.toString());
        });
    }

    public static void inserir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE INSERIR");
        nome = JOptionPane.showInputDialog("NOME");
        fornecedor = JOptionPane.showInputDialog("FORNECEDOR");
        valor = JOptionPane.showInputDialog("VALOR");
        validade = JOptionPane.showInputDialog("VALIDADE");
        Produto pEntrada = new Produto(nome,fornecedor,valor,validade);
        contP = new ControleProduto();
        Produto pSaida = contP.inserir(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }
    
    public static void alterar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE ALTERAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        nome = JOptionPane.showInputDialog("NOME");
        fornecedor = JOptionPane.showInputDialog("FORNECEDOR");
        valor = JOptionPane.showInputDialog("VALOR");
        validade = JOptionPane.showInputDialog("VALIDADE");
        Produto pEntrada = new Produto(id,nome,fornecedor,valor,validade);
        contP = new ControleProduto();
        Produto pSaida = contP.alterar(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }
    
    public static void buscar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE BUSCAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Produto pEntrada = new Produto(id);
        contP = new ControleProduto();
        Produto pSaida = contP.buscar(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }

    public static void excluir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE EXCLUIR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Produto pEntrada = new Produto(id);
        contP = new ControleProduto();
        Produto pSaida = contP.excluir(pEntrada);
        JOptionPane.showMessageDialog(null,pSaida.toString());
    }

}
