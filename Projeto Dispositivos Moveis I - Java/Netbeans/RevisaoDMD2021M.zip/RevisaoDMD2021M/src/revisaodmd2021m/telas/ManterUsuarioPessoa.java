/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.telas;

import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import revisaodmd2021m.beans.Pessoa;
import revisaodmd2021m.beans.Usuario;
import revisaodmd2021m.beans.UsuarioPessoa;
import revisaodmd2021m.controles.ControlePessoa;
import revisaodmd2021m.controles.ControleUsuario;
import revisaodmd2021m.controles.ControleUsuarioPessoa;
import static revisaodmd2021m.telas.ManterPessoa.contP;
import static revisaodmd2021m.telas.ManterUsuario.contU;

/**
 *
 * @author User
 */
public class ManterUsuarioPessoa {
    
    static int id;
    static int idU;
    static int idP;
    static String obs;
    static Usuario usu;
    static Pessoa pes;
    static ControleUsuarioPessoa contUsuPes;

    public static void buscar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE BUSCAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        idU = Integer.parseInt(JOptionPane.showInputDialog("IDU"));
        idP = Integer.parseInt(JOptionPane.showInputDialog("IDP"));
        UsuarioPessoa usupesEntrada = new UsuarioPessoa(id);
        Usuario uEntrada = new Usuario(id);
        Pessoa pEntrada = new Pessoa(id);
        contU = new ControleUsuario();
        contP = new ControlePessoa();
        contUsuPes = new ControleUsuarioPessoa();
        Usuario uSaida = contU.buscar(uEntrada);
        Pessoa pSaida = contP.buscar(pEntrada);
        UsuarioPessoa usupesSaida = contUsuPes.busca(usupesEntrada);
        System.out.println(uSaida.toString());
        System.out.println(pSaida.toString());
        System.out.println(usupesSaida.toString());
        JOptionPane.showMessageDialog(null,uSaida.toString());
        JOptionPane.showMessageDialog(null,pSaida.toString());
        JOptionPane.showMessageDialog(null,usupesSaida.toString());
    }

    public static void lista() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE LISTAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        idU = Integer.parseInt(JOptionPane.showInputDialog("IDU"));
        idP = Integer.parseInt(JOptionPane.showInputDialog("IDP"));
        UsuarioPessoa usupesEntrada = new UsuarioPessoa(id);
        contUsuPes = new ControleUsuarioPessoa();
        List<UsuarioPessoa> usupesSaida = contUsuPes.lista(usupesEntrada);
        usupesSaida.forEach((usupesL) -> {
            JOptionPane.showMessageDialog(null,usupesL.toString());
        });
    }

    public static void inserir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE INSERIR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        idU = Integer.parseInt(JOptionPane.showInputDialog("IDU"));
        idP = Integer.parseInt(JOptionPane.showInputDialog("IDP"));
        obs = JOptionPane.showInputDialog("OBS");
        UsuarioPessoa usupesEntrada = new UsuarioPessoa(id,idU,idP,obs);
        contUsuPes = new ControleUsuarioPessoa();
        UsuarioPessoa usupesSaida = contUsuPes.inseri(usupesEntrada);
        JOptionPane.showMessageDialog(null,usupesSaida.toString());
    }
    
    public static void alterar() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE ALTERAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        idU = Integer.parseInt(JOptionPane.showInputDialog("IDU"));
        idP = Integer.parseInt(JOptionPane.showInputDialog("IDP"));
        obs = JOptionPane.showInputDialog("OBS");
        UsuarioPessoa usupesEntrada = new UsuarioPessoa(id,idU,idP,obs);
        contUsuPes = new ControleUsuarioPessoa();
        UsuarioPessoa usupesSaida = contUsuPes.altera(usupesEntrada);
        JOptionPane.showMessageDialog(null,usupesSaida.toString());
    }

    public static void excluir() throws SQLException, ClassNotFoundException {
        JOptionPane.showMessageDialog(null,"TELA DE EXCLUIR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        UsuarioPessoa usupesEntrada = new UsuarioPessoa(id);
        contUsuPes = new ControleUsuarioPessoa();
        UsuarioPessoa usupesSaida = contUsuPes.exclui(usupesEntrada);
        JOptionPane.showMessageDialog(null,usupesSaida.toString());
    }

}
