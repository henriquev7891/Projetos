/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.telas;

import java.util.List;
import javax.swing.JOptionPane;
import revisaodmd2021m.beans.Cliente;
import revisaodmd2021m.controles.ControleCliente;

/**
 *
 * @author User
 */
public class ManterCliente {
    
    static int id;
    static String nome;
    static String cpf;
    static String cnpj;
    static String descricao;
    
    static ControleCliente contC = new ControleCliente();

    
    public static void listar() {
        JOptionPane.showMessageDialog(null,"TELA DE LISTAR");
        nome = JOptionPane.showInputDialog("NOME");
        Cliente cEntrada = new Cliente(nome);
        List<Cliente> csSaida = contC.listar(cEntrada);
        JOptionPane.showMessageDialog(null,csSaida.get(0).toString());
    }

    public static void inserir() {
        JOptionPane.showMessageDialog(null,"TELA DE INSERIR");
        nome = JOptionPane.showInputDialog("NOME");
        cpf = JOptionPane.showInputDialog("CPF");
        cnpj = JOptionPane.showInputDialog("CNPF");
        descricao = JOptionPane.showInputDialog("DESCRICAO");
        Cliente cEntrada = new Cliente(nome,cpf,cnpj,descricao);
        Cliente cSaida = contC.inserir(cEntrada);
        JOptionPane.showMessageDialog(null,cSaida.toString());
    }
    
    public static void alterar() {
        JOptionPane.showMessageDialog(null,"TELA DE ALTERAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        nome = JOptionPane.showInputDialog("NOME");
        cpf = JOptionPane.showInputDialog("CPF");
        cnpj = JOptionPane.showInputDialog("CNPF");
        descricao = JOptionPane.showInputDialog("DESCRICAO");
        Cliente cEntrada = new Cliente(id,nome,cpf,cnpj,descricao);
        Cliente cSaida = contC.alterar(cEntrada);
        JOptionPane.showMessageDialog(null,cSaida.toString());
    }
    
    public static void buscar() {
        JOptionPane.showMessageDialog(null,"TELA DE BUSCAR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Cliente cEntrada = new Cliente(id);
        Cliente cSaida = contC.buscar(cEntrada);
        JOptionPane.showMessageDialog(null,cSaida.toString());
    }

    public static void excluir() {
        JOptionPane.showMessageDialog(null,"TELA DE EXCLUIR");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Cliente cEntrada = new Cliente(id);
        Cliente cSaida = contC.excluir(cEntrada);
        JOptionPane.showMessageDialog(null,cSaida.toString());
    }

    
}
