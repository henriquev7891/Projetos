/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m;

import java.sql.SQLException;
import javax.swing.JOptionPane;
import revisaodmd2021m.telas.ManterCliente;
import revisaodmd2021m.telas.ManterDepartamento;
import revisaodmd2021m.telas.ManterPessoa;
import revisaodmd2021m.telas.ManterProduto;
import revisaodmd2021m.telas.ManterUsuario;
import revisaodmd2021m.telas.ManterUsuarioPessoa;

/**
 *
 * @author User
 */
public class RevisaoDMD2021M {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
            
            JOptionPane.showMessageDialog(null,"1 - MANTER PESSOA, 2 - MANTER PRODUTO, 3 - MANTER USUARIO, 4 - MANTER CLIENTE, 5 - MANTER DEPARTAMENTO, 6 - MANTER USUARIO PESSOA");
            int opcao = Integer.parseInt(JOptionPane.showInputDialog("OPCAO"));
        
            if(opcao == 1) {
                ManterPessoa.listar();
                ManterPessoa.inserir();
                ManterPessoa.alterar();
                ManterPessoa.buscar();
                ManterPessoa.excluir();
            }
            
            if(opcao == 2) {
                ManterProduto.listar();
                ManterProduto.inserir();
                ManterProduto.alterar();
                ManterProduto.buscar();
                ManterProduto.excluir();
            }

            if(opcao == 3) {
                ManterUsuario.validar();
                ManterUsuario.listar();
                ManterUsuario.inserir();
                ManterUsuario.alterar();
                ManterUsuario.buscar();
                ManterUsuario.excluir();
            }
            
            if(opcao == 4) {
                ManterCliente.listar();
                ManterCliente.inserir();
                ManterCliente.alterar();
                ManterCliente.buscar();
                ManterCliente.excluir();
            }
            
            if(opcao == 5) {
                ManterDepartamento.listar();
                ManterDepartamento.inserir();
                ManterDepartamento.alterar();
                ManterDepartamento.buscar();
                ManterDepartamento.excluir();
            }
            
            if(opcao == 6) {
                ManterUsuarioPessoa.lista();
                ManterUsuarioPessoa.inserir();
                ManterUsuarioPessoa.alterar();
                ManterUsuarioPessoa.buscar();
                ManterUsuarioPessoa.excluir();
            }

    }
    
}
