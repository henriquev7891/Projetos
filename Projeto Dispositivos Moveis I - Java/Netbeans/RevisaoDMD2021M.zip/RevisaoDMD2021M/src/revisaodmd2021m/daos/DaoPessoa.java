/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.daos;

// importações necessárias para os metodos
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import revisaodmd2021m.beans.Pessoa;
import revisaodmd2021m.util.ConexaoDb;

/**
 *
 * @author User
 */
public class DaoPessoa {
    

    // variavel de conexão
    private final Connection c;
   
    // metodo construtor que valoriza a varivel de conexão
    public DaoPessoa() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDb().getConnection();
    }

    // metodo de busca por id
    public Pessoa buscar (Pessoa pEntrada) throws SQLException {
        // select por id;
        String sql = "select * from pes_pessoa WHERE pes_id = ?";
        // variavel de retorno
        Pessoa retorno;
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setInt(1,pEntrada.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            retorno = null;
            // percorre o resultset
            while (rs.next()) {
                // criando o objeto Usuario
                retorno = new Pessoa(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                );
            }
        }
        c.close();
        return retorno;
    }

    public Pessoa inserir(Pessoa pEntrada) throws SQLException {
        // escrevo meu select
        String sql = "INSERT INTO pes_pessoa (pes_nome,pes_peso,pes_idade,pes_altura,pes_genero) VALUES(?,?,?,?,?)";
        // variavel de retorno
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            // seta os valores
            stmt.setString(1,pEntrada.getNome());
            stmt.setString(2,pEntrada.getPeso());
            stmt.setString(3,pEntrada.getIdade());
            stmt.setString(4,pEntrada.getAltura());
            stmt.setString(5,pEntrada.getGenero());
            // executa
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            // carrego no bean o id que foi gerado pelo banco de dados
            if(rs.next()) {
                int id = rs.getInt(1);
                pEntrada.setId(id);
            }
        }
        c.close();
        return pEntrada;
    }

    public Pessoa alterar(Pessoa pEntrada) throws SQLException {
    // escrevo meu select
        String sql = "UPDATE pes_pessoa SET pes_nome = ?,pes_peso = ?,pes_idade = ?,pes_altura= ?,pes_genero= ? WHERE pes_id = ?";
        // variavel de retorno
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setString(1,pEntrada.getNome());
            stmt.setString(2,pEntrada.getPeso());
            stmt.setString(3,pEntrada.getIdade());
            stmt.setString(4,pEntrada.getAltura());
            stmt.setString(5,pEntrada.getGenero());
            stmt.setInt(6,pEntrada.getId());
            // executa
            stmt.execute();
        }
        c.close();
        return pEntrada;
    }

    public Pessoa excluir(Pessoa pEntrada) throws SQLException {
        // escrevo meu select
        String sql = "delete from pes_pessoa WHERE pes_id = ?";
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setInt(1,pEntrada.getId());
            // executa
            stmt.execute();
        }
        c.close();
        return pEntrada;
    }

    public List<Pessoa> listar(Pessoa pEntrada) throws SQLException {
        List<Pessoa> pess = new ArrayList<>();
        // escrevo meu select
        String sql = "select * from pes_pessoa WHERE pes_nome like ?";
        // variavel de retorno
        Pessoa retorno;
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setString(1,"%" + pEntrada.getNome() + "%");
            // executa
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                // criando o objeto Usuario
                 retorno = new Pessoa(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6));
                pess.add(retorno);
            }
        }
        c.close();
        return pess;
    }

    public List<Pessoa> lista(Pessoa pes) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
