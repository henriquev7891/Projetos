/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.daos;

import java.util.ArrayList;
import java.util.List;
import revisaodmd2021m.beans.Cliente;

/**
 *
 * @author User
 */
public class DaoCliente {

    public List<Cliente> listar(Cliente cEntrada) {
        List<Cliente> listC = new ArrayList<>();
        listC.add(cEntrada);
        return listC;
    }

    public Cliente inserir(Cliente cEntrada) {
        return cEntrada;
    }

    public Cliente alterar(Cliente cEntrada) {
        return cEntrada;
    }

    public Cliente excluir(Cliente cEntrada) {
        return cEntrada;
    }

    public Cliente buscar(Cliente cEntrada) {
        return cEntrada;
    }
    
}
