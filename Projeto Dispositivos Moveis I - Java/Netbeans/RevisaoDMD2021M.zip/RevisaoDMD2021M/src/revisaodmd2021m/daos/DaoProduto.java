/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.daos;

import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import revisaodmd2021m.beans.Produto;
import revisaodmd2021m.util.ConexaoDb;

/**
 *
 * @author User
 */
public class DaoProduto {
    

    // variavel de conexão
    private final Connection c;
   
    // metodo construtor que valoriza a varivel de conexão
    public DaoProduto() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDb().getConnection();
    }

    // metodo de busca por id
    public Produto buscar (Produto pEntrada) throws SQLException {
        // select por id;
        String sql = "select * from p_produto WHERE p_id = ?";
        // variavel de retorno
        Produto retorno;
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setInt(1,pEntrada.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            retorno = null;
            // percorre o resultset
            while (rs.next()) {
                // criando o objeto Produto
                retorno = new Produto(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5)
                );
            }
        }
        c.close();
        return retorno;
    }

    public Produto inserir(Produto pEntrada) throws SQLException {
        // escrevo meu select
        String sql = "INSERT INTO p_produto (p_nome,p_fornecedor,p_valor,p_validade) VALUES(?,?,?,?)";
        // variavel de retorno
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            // seta os valores
            stmt.setString(1,pEntrada.getNome());
            stmt.setString(2,pEntrada.getFornecedor());
            stmt.setString(3,pEntrada.getValor());
            stmt.setString(4,pEntrada.getValidade());
            // executa
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            // carrego no bean o id que foi gerado pelo banco de dados
            if(rs.next()) {
                int id = rs.getInt(1);
                pEntrada.setId(id);
            }
        }
        c.close();
        return pEntrada;
    }

    public Produto alterar(Produto pEntrada) throws SQLException {
    // escrevo meu select
        String sql = "UPDATE p_produto SET p_nome = ?,p_fornecedor = ?,p_valor = ?,p_validade= ? WHERE p_id = ?";
        // variavel de retorno
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setString(1,pEntrada.getNome());
            stmt.setString(2,pEntrada.getFornecedor());
            stmt.setString(3,pEntrada.getValor());
            stmt.setString(4,pEntrada.getValidade());
            stmt.setInt(5,pEntrada.getId());
            // executa
            stmt.execute();
        }
        c.close();
        return pEntrada;
    }

    public Produto excluir(Produto pEntrada) throws SQLException {
        // escrevo meu select
        String sql = "delete from p_produto WHERE p_id = ?";
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setInt(1,pEntrada.getId());
            // executa
            stmt.execute();
        }
        c.close();
        return pEntrada;
    }

    public List<Produto> listar(Produto pEntrada) throws SQLException {
        List<Produto> produ = new ArrayList<>();
        // escrevo meu select
        String sql = "select * from p_produto WHERE p_nome like ?";
        // variavel de retorno
        Produto retorno;
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setString(1,"%" + pEntrada.getNome() + "%");
            // executa
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                // criando o objeto Produto
                 retorno = new Produto(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5));
                produ.add(retorno);
            }
        }
        c.close();
        return produ;
    }
}