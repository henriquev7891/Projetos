/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.daos;

// importações necessárias para os metodos
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Statement;
import revisaodmd2021m.beans.Departamento;
import revisaodmd2021m.util.ConexaoDb;

/**
 *
 * @author User
 */
public class DaoDepartamento {
    

    // variavel de conexão
    private final Connection c;
   
    // metodo construtor que valoriza a varivel de conexão
    public DaoDepartamento() throws SQLException, ClassNotFoundException{
        this.c = new ConexaoDb().getConnection();
    }

    // metodo de busca por id
    public Departamento buscar (Departamento dEntrada) throws SQLException {
        // select por id;
        String sql = "select * from dep_departamento WHERE dep_id = ?";
        // variavel de retorno
        Departamento retorno;
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setInt(1,dEntrada.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            retorno = null;
            // percorre o resultset
            while (rs.next()) {
                // criando o objeto Usuario
                retorno = new Departamento(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4));
            }
        }
        c.close();
        return retorno;
    }

    public Departamento inserir(Departamento dEntrada) throws SQLException {
        // escrevo meu select
        String sql = "INSERT INTO dep_departamento (dep_nome,dep_desc,dep_centrocusto) VALUES(?,?,?)";
        // variavel de retorno
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            // seta os valores
            stmt.setString(1,dEntrada.getNome());
            stmt.setString(2,dEntrada.getDesc());
            stmt.setString(3,dEntrada.getCentrocusto());
            // executa
            stmt.executeUpdate();
            ResultSet rs = stmt.getGeneratedKeys();
            // carrego no bean o id que foi gerado pelo banco de dados
            if(rs.next()) {
                int id = rs.getInt(1);
                dEntrada.setId(id);
            }
        }
        c.close();
        return dEntrada;
    }

    public Departamento alterar(Departamento dEntrada) throws SQLException {
    // escrevo meu select
        String sql = "UPDATE dep_departamento SET dep_nome = ?,dep_desc = ?,dep_centrocusto = ? WHERE dep_id = ?";
        // variavel de retorno
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setString(1,dEntrada.getNome());
            stmt.setString(2,dEntrada.getDesc());
            stmt.setString(3,dEntrada.getCentrocusto());
            stmt.setInt(4,dEntrada.getId());
            // executa
            stmt.execute();
        }
        c.close();
        return dEntrada;
    }

    public Departamento excluir(Departamento dEntrada) throws SQLException {
        // escrevo meu Departamento
        String sql = "delete from dep_departamento WHERE dep_id = ?";
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setInt(1,dEntrada.getId());
            // executa
            stmt.execute();
        }
        c.close();
        return dEntrada;
    }

    public List<Departamento> listar(Departamento dEntrada) throws SQLException {
        List<Departamento> deps = new ArrayList<>();
        // escrevo meu select
        String sql = "select * from dep_departamento WHERE dep_nome like ?";
        // variavel de retorno
        Departamento retorno;
        // seta os valores
        try (PreparedStatement stmt = this.c.prepareStatement(sql)) {
            // seta os valores
            stmt.setString(1,"%" + dEntrada.getNome()+ "%");
            // executa
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                // criando o objeto Usuario
                 retorno = new Departamento(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4));
                deps.add(retorno);
            }
        }
        c.close();
        return deps;
    }

}
