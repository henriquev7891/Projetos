/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.controles;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import revisaodmd2021m.beans.Pessoa;
import revisaodmd2021m.beans.Usuario;
import revisaodmd2021m.beans.UsuarioPessoa;
import revisaodmd2021m.daos.DaoUsuarioPessoa;

/**
 *
 * @author User
 */
public class ControleUsuarioPessoa {
    
    static DaoUsuarioPessoa daoUsuPes;
    static ControleUsuario contUsu;
    static ControlePessoa contPes;

    public ControleUsuarioPessoa() throws SQLException, ClassNotFoundException {
        daoUsuPes = new DaoUsuarioPessoa();
        contUsu = new ControleUsuario();
        contPes = new ControlePessoa();
    }

    public UsuarioPessoa busca (UsuarioPessoa usupes) throws SQLException {
        
        // busca UsuarioPessoa por id
        usupes = daoUsuPes.busca(usupes);
        // construi os beans com os id de retorno de usuPes
        Usuario usu = new Usuario(usupes.getIdU());
        Pessoa pes = new Pessoa(usupes.getIdP());
        // valorizar os beans de usuario e pessao executando
        // seus controles.
        usupes.setUsu(contUsu.buscar(usu));
        usupes.setPes(contPes.buscar(pes));
        
        return usupes;
    }

    public UsuarioPessoa inseri (UsuarioPessoa usupes) throws SQLException {
        usupes = daoUsuPes.inseri(usupes);
        return usupes;
    }

    public UsuarioPessoa altera (UsuarioPessoa usupes) throws SQLException {
        usupes = daoUsuPes.altera(usupes);
        return usupes;
    }

    public UsuarioPessoa exclui (UsuarioPessoa usupes) throws SQLException {
        usupes = daoUsuPes.exclui(usupes);
        return usupes;
    }

    public List<UsuarioPessoa> lista (UsuarioPessoa usupes) throws SQLException, ClassNotFoundException {

        List<UsuarioPessoa> usupess;
        usupess = daoUsuPes.lista(usupes);
        for (UsuarioPessoa usupesL : usupess) {
        contUsu = new ControleUsuario();
        contPes = new ControlePessoa();
        Usuario usu = new Usuario(usupesL.getIdU());
        Pessoa pes = new Pessoa(usupesL.getIdP());
        // valorizar os beans de usuario e pessao executando
        // seus controles.
        usupesL.setUsu(contUsu.buscar(usu));
        usupesL.setPes(contPes.buscar(pes));
        }
        return usupess;
    }  
}
