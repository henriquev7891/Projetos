/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.controles;

import java.util.List;
import java.sql.SQLException;
import revisaodmd2021m.beans.Produto;
import revisaodmd2021m.daos.DaoProduto;

/**
 *
 * @author User
 */
public class ControleProduto {

   static DaoProduto daoPro;
    
    public ControleProduto () throws SQLException, ClassNotFoundException {
        daoPro = new DaoProduto();
    }
             
    public Produto buscar(Produto pEntrada) throws SQLException {
        return daoPro.buscar(pEntrada);
    }

    public List<Produto> listar(Produto pEntrada) throws SQLException {
        return daoPro.listar(pEntrada);
    }

    public Produto inserir(Produto pEntrada) throws SQLException {
        return daoPro.inserir(pEntrada);
    }

    public Produto alterar(Produto pEntrada) throws SQLException {
        return daoPro.alterar(pEntrada);
    }

    public Produto excluir(Produto pEntrada) throws SQLException {
        return daoPro.excluir(pEntrada);
    }
}
