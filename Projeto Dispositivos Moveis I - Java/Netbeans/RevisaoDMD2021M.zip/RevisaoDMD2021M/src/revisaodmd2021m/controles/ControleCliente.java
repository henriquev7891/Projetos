/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.controles;

import java.util.List;
import revisaodmd2021m.beans.Cliente;
import revisaodmd2021m.daos.DaoCliente;

/**
 *
 * @author User
 */
public class ControleCliente {

    static DaoCliente daoCli = new DaoCliente();

    public List<Cliente> listar(Cliente cEntrada) {
        return daoCli.listar(cEntrada);
    }

    public Cliente inserir(Cliente cEntrada) {
        return daoCli.inserir(cEntrada);
    }

    public Cliente alterar(Cliente cEntrada) {
        return daoCli.alterar(cEntrada);
    }

    public Cliente excluir(Cliente cEntrada) {
        return daoCli.excluir(cEntrada);
    }

    public Cliente buscar(Cliente cEntrada) {
        return daoCli.buscar(cEntrada);
    }
    
}
