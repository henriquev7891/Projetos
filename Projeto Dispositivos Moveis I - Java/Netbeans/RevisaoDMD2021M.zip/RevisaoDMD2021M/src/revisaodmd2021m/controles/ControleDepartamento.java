/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.controles;

import java.util.List;
import java.sql.SQLException;
import revisaodmd2021m.beans.Departamento;
import revisaodmd2021m.daos.DaoDepartamento;

/**
 *
 * @author User
 */
public class ControleDepartamento {
    
    static DaoDepartamento daoDep; 
    
    public ControleDepartamento () throws SQLException, ClassNotFoundException {
        daoDep = new DaoDepartamento();
    }
             
    public Departamento buscar(Departamento dEntrada) throws SQLException {
        return daoDep.buscar(dEntrada);
    }

    public List<Departamento> listar(Departamento dEntrada) throws SQLException {
        return daoDep.listar(dEntrada);
    }

    public Departamento inserir(Departamento dEntrada) throws SQLException {
        return daoDep.inserir(dEntrada);
    }

    public Departamento alterar(Departamento dEntrada) throws SQLException {
        return daoDep.alterar(dEntrada);
    }

    public Departamento excluir(Departamento dEntrada) throws SQLException {
        return daoDep.excluir(dEntrada);
    }
}
