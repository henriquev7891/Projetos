/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revisaodmd2021m.controles;

import java.util.List;
import java.sql.SQLException;
import java.util.ArrayList;
import revisaodmd2021m.beans.Pessoa;
import revisaodmd2021m.daos.DaoPessoa;

/**
 *
 * @author User
 */
public class ControlePessoa {
    
    static DaoPessoa daoPes; 
    
    public ControlePessoa () throws SQLException, ClassNotFoundException {
        daoPes = new DaoPessoa();
    }
             
    public Pessoa buscar(Pessoa pEntrada) throws SQLException {
        return daoPes.buscar(pEntrada);
    }

    public List<Pessoa> listar(Pessoa pEntrada) throws SQLException {
        return daoPes.listar(pEntrada);
    }

    public Pessoa inserir(Pessoa pEntrada) throws SQLException {
        return daoPes.inserir(pEntrada);
    }

    public Pessoa alterar(Pessoa pEntrada) throws SQLException {
        return daoPes.alterar(pEntrada);
    }

    public Pessoa excluir(Pessoa pEntrada) throws SQLException {
        return daoPes.excluir(pEntrada);
    }
    
    public List<Pessoa> lista (Pessoa pes) throws SQLException {
        List<Pessoa> pess = new ArrayList<>();
        pess = daoPes.lista(pes);
        return pess;
    }
}
