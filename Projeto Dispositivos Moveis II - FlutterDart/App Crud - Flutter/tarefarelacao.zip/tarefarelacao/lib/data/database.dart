import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';

class DatabaseRepository {
  DatabaseRepository.privateConstructor();

  static final DatabaseRepository instance =
  DatabaseRepository.privateConstructor(); // Criacao da DataBase

  final _databaseName = 'database3'; // Nome da DataBase
  final _databaseVersion = 1;

  static Database _database;

  Future<Database> get database async {
    // Verificando se ela foi criada
    if (_database != null) {
      return _database;
    } else {
      _database = await _initDatabase();
    }
  }

  _initDatabase() async {
    // Inicio do Activity
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(path,
        version: _databaseVersion, onCreate: await onCreate);
  }

  Future onCreate(Database db, int version) async {
    // Criacao da tabela Usuario
    await db.execute('''
          CREATE TABLE usuario (
            usuarioId INTEGER PRIMARY KEY AUTOINCREMENT,
            usuarioLogin STRING NOT NULL,
            usuarioSenha STRING NOT NULL,
            usuarioStatus STRING NOT NULL,
            FK_usuario_category INT NOT NULL,
            FOREIGN KEY (FK_usuario_category) REFERENCES category (categoryId) 
            
          )
          ''');
    // Criacao da tabela Categoria
    await db.execute(''' 
          CREATE TABLE category (
            categoryId INTEGER PRIMARY KEY AUTOINCREMENT,
            categoryName STRING NOT NULL
          )
          ''');
    // n para n / vai puxar todos os usuarios e categorias
    await db.execute('''
          CREATE TABLE usuarios_categorys (
            usucateId INTEGER PRIMARY KEY AUTOINCREMENT,
            usuarioId INTEGER NOT NULL,
            categoryId INTEGER NOT NULL,
            observacaoR STRING NOT NULL,
            FK_usuario_category INT NOT NULL,
            FK_category_usuario INT NOT NULL,
            FOREIGN KEY (FK_usuario_category) REFERENCES usuario (usuarioId) 
            FOREIGN KEY (FK_usuario_category) REFERENCES category (categoryId)
            
          )
          ''');
  }
}