import 'package:tarefarelacao/data/database.dart';
import 'package:tarefarelacao/models/category.dart';
import 'package:tarefarelacao/models/usuario.dart';
import 'package:tarefarelacao/models/usuarios_categorys.dart';

class UsuarioOperations {
  UsuarioOperations usuarioOperations;

  final dbProvider = DatabaseRepository.instance;

  createUsuario(Usuario usuario) async {
    final db = await dbProvider.database;
    db.insert('usuario', usuario.toMap());
    print('usuario inserido');
  }

  updateUsuario(Usuario usuario) async {
    final db = await dbProvider.database;
    db.update('usuario', usuario.toMap(),
        where: "usuarioId=?", whereArgs: [usuario.id]);
  }

  deleteUsuario(Usuario usuario) async {
    final db = await dbProvider.database;
    await db.delete('usuario', where: 'usuarioId=?', whereArgs: [usuario.id]);
  }

  Future<List<Usuario>> getAllUsuarios() async {
    final db = await dbProvider.database;
    List<Map<String, dynamic>> allRows = await db.query('usuario');
    List<Usuario> usuarios =
    allRows.map((usuario) => Usuario.fromMap(usuario)).toList();
    return usuarios;
  }
    //Relacao n:n
  Future<List<Usuarios_categorys>> getAllUsuariosCategorys() async {
    final db = await dbProvider.database;
    List<Map<String, dynamic>> allRows = await db.query('usuarios_categorys');
    List<Usuarios_categorys> usuarios_categorys =
    allRows.map((usuarios_categorys) => Usuarios_categorys.fromMap(usuarios_categorys)).toList();
    return usuarios_categorys;
  }
// fim relacao
  Future<List<Usuario>> getAllUsuariosByCategory(Category category) async {
    final db = await dbProvider.database;
    List<Map<String, dynamic>> allRows = await db.rawQuery('''
    SELECT * FROM usuario 
    WHERE usuario.FK_usuario_category = ${category.id}
    ''');
    List<Usuario> usuarios =
    allRows.map((usuario) => Usuario.fromMap(usuario)).toList();
    return usuarios;
  }

  Future<List<Usuario>> searchUsuarios(String keyword) async {
    final db = await dbProvider.database;
    List<Map<String, dynamic>> allRows = await db
        .query('usuario', where: 'usuarioLogin LIKE ?', whereArgs: ['%$keyword%']);
    List<Usuario> usuarios =
    allRows.map((usuario) => Usuario.fromMap(usuario)).toList();
    return usuarios;
  }
  //Relacao n:n
  Future<List<Usuarios_categorys>> searchUsuarios_categorys(String keyword) async {
    final db = await dbProvider.database;
    List<Map<String, dynamic>> allRows = await db
        .query('usuarios_categorys', where: 'observacaoR LIKE ?', whereArgs: ['%$keyword%']);
    List<Usuarios_categorys> Usuarios_categoryss =
    allRows.map((usuarios_categorys) => Usuarios_categorys.fromMap(usuarios_categorys)).toList();
    return Usuarios_categoryss;
  }
  //fim relacao
}

// WHERE nome LIKE 'keyword%'
// - Encontra todos os valores que começam com "keyword"
// WHERE nome LIKE '%keyword'
// - Encontra todos os valores que terminam com "keyword"
// WHERE nome LIKE '%keyword%'
// - Encontra qualquer valor que tenha "keyword" em qualquer posição