import 'package:tarefarelacao/data/database.dart';
import 'package:tarefarelacao/models/category.dart';

class CategoryOperations {
  CategoryOperations categoryOperations;

  final dbProvider = DatabaseRepository.instance;

  createCategory(Category category) async { // Insert da Tabela Category
    final db = await dbProvider.database;
    db.insert('category', category.toMap());
  }
  

  Future<List<Category>> getAllCategories() async { // Lista todas categorias
    final db = await dbProvider.database;
    List<Map<String, dynamic>> allRows = await db.query('category');
    List<Category> categories =
    allRows.map((category) => Category.fromMap(category)).toList();
    return categories;
  }

  
}


