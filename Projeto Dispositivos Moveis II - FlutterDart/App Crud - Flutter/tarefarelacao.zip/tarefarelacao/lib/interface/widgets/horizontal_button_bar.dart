import 'package:flutter/material.dart';

class HorizontalButtonBar extends StatelessWidget {
  HorizontalButtonBar({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          FloatingActionButton(
            heroTag: 'usuarios',
            onPressed: () {
              Navigator.of(context).pushReplacementNamed('/addUsuarioPage');
            },
            child: Icon(Icons.person_add),
          ),
          FloatingActionButton(
            heroTag: 'search',
            onPressed: () {
              Navigator.of(context).pushReplacementNamed('/searchPage');
            },
            child: Icon(Icons.search),
          ),
          FloatingActionButton(
            heroTag: 'Adicionar Categoria',
            onPressed: () {
              Navigator.of(context).pushReplacementNamed('/addCategoryPage');
            },
            child: Icon(Icons.playlist_add_rounded),
          ),
          FloatingActionButton(
            heroTag: 'Buscar Usuarios por Categoria',
            onPressed: () {
              Navigator.of(context).pushReplacementNamed('/searchUsuariosByCategory');
            },
              child: Icon(Icons.list),
          ),

        ],
      ),
    );
  }
}
