import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tarefarelacao/data/usuario_operations.dart';
import 'package:tarefarelacao/models/usuario.dart';
import 'package:tarefarelacao/interface/pages/edit_usuario_page.dart';

class UsuariosList extends StatelessWidget {
  List<Usuario> usuarios;
  UsuarioOperations usuarioOperations = UsuarioOperations();

  UsuariosList(List<Usuario> this.usuarios, {
    Key key
  }):super(key: key);


  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: usuarios.length,
        itemBuilder: (BuildContext context, int index) {
          return Dismissible(
            key: Key('${usuarios[index].id}'),
            child: Padding(
              padding: const EdgeInsets.all(6.0),
              child: Container(
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(5)),
                  width: MediaQuery.of(context).size.width,
                  height: 50,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          ' ${usuarios[index].id} ',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          ' ${usuarios[index].login}  ${usuarios[index].senha}  ${usuarios[index].status}',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: RaisedButton(
                            onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => EditUsuarioPage(
                                      usuario: usuarios[index],
                                    )));
                            },
                            color: Colors.orange,
                            child: Icon(Icons.edit, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  )),
            ),
            onDismissed: (direction) {
              usuarioOperations.deleteUsuario(usuarios[index]);
            },
          );
        },
      ),
    );
  }
}
