import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tarefarelacao/data/usuario_operations.dart';
import 'package:tarefarelacao/models/usuario.dart';
import 'package:tarefarelacao/models/usuarios_categorys.dart';
import 'package:tarefarelacao/interface/pages/edit_usuario_page.dart';

class UsuariosCategorysList extends StatelessWidget {
  List<Usuarios_categorys> usuarios_categoryss;
  UsuarioOperations usuarioOperations = UsuarioOperations();

  UsuariosCategorysList(List<Usuarios_categorys> this.usuarios_categoryss, {
    Key key
  }):super(key: key);


  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView.builder(
        scrollDirection: Axis.vertical,
        shrinkWrap: true,
        itemCount: usuarios_categoryss.length,
        itemBuilder: (BuildContext context, int index) {
          return Dismissible(
            key: Key('${usuarios_categoryss[index].id}'),
            child: Padding(
              padding: const EdgeInsets.all(6.0),
              child: Container(
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(5)),
                  width: MediaQuery.of(context).size.width,
                  height: 50,
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          ' ${usuarios_categoryss[index].id} ',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          '${usuarios_categoryss[index].idusuario}  ${usuarios_categoryss[index].idcategoria}',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  )),
            ),
          );
        },
      ),
    );
  }
}
