import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tarefarelacao/data/usuario_operations.dart';
import 'package:tarefarelacao/interface/widgets/usuario_list.dart';
import 'package:tarefarelacao/interface/widgets/horizontal_button_bar.dart';

class UsuariosPage extends StatefulWidget {
  UsuariosPage({Key key})
      : super(
          key: key,
        );

  @override
  _UsuariosPageState createState() => _UsuariosPageState();
}

class _UsuariosPageState extends State<UsuariosPage> {
  UsuarioOperations usuarioOperations = UsuarioOperations();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Relação'),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                HorizontalButtonBar(),
                FutureBuilder(
                  future: usuarioOperations.getAllUsuarios(),
                  builder: (context, snapshot){
                    if(snapshot.hasError) print('error');
                    var data = snapshot.data;
                    return snapshot.hasData ? UsuariosList(data) : new Center(child: Text('Nenhum Usuario'),);
                  },
                ),
              ],
            ),

        ),
      ),
    );
  }
}
