import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tarefarelacao/data/category_operations.dart';
import 'package:tarefarelacao/data/usuario_operations.dart';
import 'package:tarefarelacao/models/usuario.dart';
import 'package:tarefarelacao/models/category.dart';
import 'package:tarefarelacao/interface/widgets/categories_dropdown.dart';
import 'package:tarefarelacao/interface/widgets/usuario_list.dart';


class SearchUsuariosByCategory extends StatefulWidget {
  SearchUsuariosByCategory({Key key}) : super(key: key);

  @override
  _SearchUsuariosByCategoryState createState() => _SearchUsuariosByCategoryState();
}

class _SearchUsuariosByCategoryState extends State<SearchUsuariosByCategory> {

  UsuarioOperations usuarioOperations = UsuarioOperations();
  CategoryOperations categoryOperations = CategoryOperations();
  Category _selectedCategory;

  callback(selectedCategory){
    setState(() {
      _selectedCategory = selectedCategory;
      print(_selectedCategory.name);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tarefa Relação'),
        leading: GestureDetector(
          onTap: () {
            Navigator.of(context).pushReplacementNamed('/homePage');
          },
          child: Icon(
            Icons.arrow_back,
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            FutureBuilder<List<Category>>(
              future: categoryOperations.getAllCategories(),
              builder: (context, snapshot) {
                return snapshot.hasData ? CategoriesDropDown(snapshot.data, callback) : Text('Nenhuma Categoria');
              },
            ),
            FutureBuilder(
              future: usuarioOperations.getAllUsuariosByCategory(_selectedCategory),
              builder: (context, snapshot){
                if(snapshot.hasError) print('error');
                var data = snapshot.data;
                return snapshot.hasData ? UsuariosList(data) : new Center(child: Text('Nenhum Usuário'),);
              },
            ),
          ],
        ),
      ),

    );
  }
}
