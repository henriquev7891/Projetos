import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tarefarelacao/data/category_operations.dart';
import 'package:tarefarelacao/data/usuario_operations.dart';
import 'package:tarefarelacao/models/usuario.dart';
import 'package:tarefarelacao/models/category.dart';
import 'package:tarefarelacao/interface/widgets/categories_dropdown.dart';


class AddUsuarioPage extends StatefulWidget {
  AddUsuarioPage({Key key}) : super(key: key);

  @override
  _AddUsuarioPageState createState() => _AddUsuarioPageState();
}

class _AddUsuarioPageState extends State<AddUsuarioPage> {  //Controllers Usuario
  final _loginController = TextEditingController();
  final _senhaController = TextEditingController();
  final _statusController = TextEditingController();
  UsuarioOperations usuarioOperations = UsuarioOperations();
  CategoryOperations categoryOperations = CategoryOperations();
  Category _selectedCategory;

  callback(selectedCategory){
    setState(() {
      _selectedCategory = selectedCategory;
      print(_selectedCategory.name);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tarefa Relação'),
        leading: GestureDetector(
          onTap: () {
            Navigator.of(context).pushReplacementNamed('/homePage');
          },
          child: Icon(
            Icons.arrow_back,
          ),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                controller: _loginController,
                decoration: InputDecoration(
                    border: OutlineInputBorder(), labelText: 'Login'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                controller: _senhaController,
                decoration: InputDecoration(
                    border: OutlineInputBorder(), labelText: 'Senha'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                controller: _statusController,
                decoration: InputDecoration(
                    border: OutlineInputBorder(), labelText: 'Status'),
              ),
            ),
            FutureBuilder<List<Category>>(
              future: categoryOperations.getAllCategories(),
              builder: (context, snapshot) {
                return snapshot.hasData ? CategoriesDropDown(snapshot.data, callback) : Text('Nenhuma Categoria');
              },
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          final usuario = Usuario(
              login: _loginController.text, senha: _senhaController.text, status: _statusController.text, category: _selectedCategory.id);
          usuarioOperations.createUsuario(usuario);
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
