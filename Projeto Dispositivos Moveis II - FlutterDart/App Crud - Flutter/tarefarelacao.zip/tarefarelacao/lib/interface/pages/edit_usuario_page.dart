import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tarefarelacao/data/usuario_operations.dart';
import 'package:tarefarelacao/models/usuario.dart';

class EditUsuarioPage extends StatefulWidget {
  Usuario usuario;

  EditUsuarioPage({Key key, this.usuario})
      : super(
          key: key,
        );

  @override
  _EditUsuarioPageState createState() => _EditUsuarioPageState();
}

class _EditUsuarioPageState extends State<EditUsuarioPage> {
  UsuarioOperations usuarioOperations = UsuarioOperations();

  var _loginController = TextEditingController();
  var _senhaController = TextEditingController();
  var _statusController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    _loginController.text = widget.usuario.login;
    _senhaController.text = widget.usuario.senha;
    _statusController.text = widget.usuario.status;
    return Scaffold(
      appBar: AppBar(
        title: Text('Tarefa Relação'),
        leading: GestureDetector(
          onTap: () {
            Navigator.of(context).pushReplacementNamed('/homePage');
          },
          child: Icon(
            Icons.arrow_back, // Adicionar icones custom
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: TextField(
                  controller: _loginController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(), labelText: 'Login'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: TextField(
                  controller: _senhaController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(), labelText: 'Senha'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: TextField(
                  controller: _statusController,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(), labelText: 'Status'),
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.edit),
        onPressed: () {
          widget.usuario.login= _loginController.text;
          widget.usuario.senha= _senhaController.text;
          widget.usuario.status= _statusController.text;

          usuarioOperations.updateUsuario(widget.usuario);
        },
      ),
    );
  }
}
