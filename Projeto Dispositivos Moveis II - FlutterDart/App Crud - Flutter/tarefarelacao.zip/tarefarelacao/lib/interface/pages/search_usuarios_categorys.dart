import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tarefarelacao/data/usuario_operations.dart';
import 'package:tarefarelacao/models/usuarios_categorys.dart';
import 'package:tarefarelacao/interface/widgets/usuarios_categoryslist.dart';

class SearchPage2 extends StatefulWidget {
  SearchPage2({
    Key key,
  }) : super(
          key: key,
        );

  @override
  _SearchPage2State createState() => _SearchPage2State();
}

class _SearchPage2State extends State<SearchPage2> {
  UsuarioOperations usuarioOperations = UsuarioOperations();
  String keyword;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tarefa Relação'),
        leading: GestureDetector(
          onTap: () {
            Navigator.of(context).pushReplacementNamed('/homePage');
          },
          child: Icon(
            Icons.arrow_back, // add custom icons also
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  decoration: InputDecoration(
                      border: OutlineInputBorder(), labelText: 'keyword'),
                  onChanged: (value) {
                    keyword = value;
                    setState(() {

                    });
                  },
                ),
              ),
              FutureBuilder(
                future: usuarioOperations.searchUsuarios_categorys(keyword),
                builder: (context, snapshot) {
                  if (snapshot.hasError) print('error');
                  var data = snapshot.data;
                  return snapshot.hasData ? UsuariosCategorysList(data) : new Center(child: Text('Nenhum Usuário com este Nome'),);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
