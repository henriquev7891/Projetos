import 'package:flutter/material.dart';
import 'package:tarefarelacao/interface/pages/add_category_page.dart';
import 'package:tarefarelacao/interface/pages/add__usuario_page.dart';
import 'package:tarefarelacao/interface/pages/usuarios_page.dart';
import 'package:tarefarelacao/interface/pages/edit_usuario_page.dart';
import 'package:tarefarelacao/interface/pages/search_usuarios.dart';
import 'package:tarefarelacao/interface/pages/search_usuarios_categorys.dart';
import 'package:tarefarelacao/interface/pages/search_usuarios_by_category.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // Widget root da aplicacao.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tarefa Relação',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      routes: {
        '/homePage': (context) => UsuariosPage(),
        '/addUsuarioPage': (context) => AddUsuarioPage(),
        '/edit': (context) => EditUsuarioPage(),
        '/searchPage': (context) => SearchPage(),
        '/searchPage2': (context) => SearchPage2(),
        '/addCategoryPage': (context) => AddCategoryPage(),
        '/searchUsuariosByCategory': (context) =>SearchUsuariosByCategory()
      },
      home: UsuariosPage(),
    );
  }
}
