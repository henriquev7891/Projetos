class Usuario {   //Criacao e mapeamento da nova instancia e dos dados dentro dela. (USUARIO)
  int id;         //Basicamente mesma coisa que o json decode faz, coleta os dados e mapeia para poder manipular
  String login;
  String senha;
  String status;
  int category;

  Usuario({this.id, this.login, this.senha, this.status, this.category});

  Usuario.fromMap(dynamic obj) {
    this.id = obj['usuarioId'];
    this.login = obj['usuarioLogin'];
    this.senha = obj['usuarioSenha'];
    this.status = obj['usuarioStatus'];
    this.category = obj['FK_usuario_category'];
  }

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'usuarioLogin': login,
      'usuarioSenha': senha,
      'usuarioStatus': status,
      'FK_usuario_category':category,
    };

    return map;
  }
}
