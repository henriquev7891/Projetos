class Category {   //Parecido com o Bean do Java //Criacao e mapeamento da nova instancia e dos dados dentro dela. (CATEGORY)
  int id;        //Basicamente mesma coisa que o json decode faz, coleta os dados e mapeia para poder manipular
  String name;   // Resumindo: fromJSON & toJSON = fromMap & toMap

  Category({
    this.id,
    this.name,
  });

  Category.fromMap(dynamic obj) {
    this.id = obj['categoryId'];
    this.name = obj['categoryName'];
  }

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'categoryName': name,
    };

    return map;
  }
}
