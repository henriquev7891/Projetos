class Usuarios_categorys {   //Criacao e mapeamento da nova instancia e dos dados dentro dela. (USUARIO)
  int id;         //Basicamente mesma coisa que o json decode faz, coleta os dados e mapeia para poder manipular
  int idusuario;
  int idcategoria;
  String observacao;
  int usuario;
  int category;

  Usuarios_categorys({this.id, this.idusuario, this.idcategoria, this.usuario, this.category, this.observacao});

  Usuarios_categorys.fromMap(dynamic obj) {
    this.id = obj['usucateId'];
    this.idusuario = obj['usuario_Id'];
    this.idcategoria = obj['observacaoR'];
    this.observacao = obj['category_Id'];
    this.usuario = obj['FK_usuario_category'];
    this.category = obj['FK_category_usuario'];
  }

  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      'usucateId': id,
      'usuario_Id': idusuario,
      'category_Id': idcategoria,
      'observacaoR': observacao,
      'FK_usuario_category':usuario,
      'FK_category_usuario':category,
    };

    return map;
  }
}
