package com.example.sqflite_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
